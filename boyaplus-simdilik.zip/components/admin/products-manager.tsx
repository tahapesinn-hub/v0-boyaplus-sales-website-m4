"use client"

import React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Plus, Pencil, Trash2, ImagePlus, ChevronUp, ChevronDown, Upload, Loader2 } from "lucide-react"
import type { Product, Category } from "@/lib/site-data"

interface ProductsManagerProps {
  products: Product[]
  categories: Category[]
  onAdd: (product: Product) => void
  onUpdate: (id: string, product: Product) => void
  onDelete: (id: string) => void
}

const MAX_IMAGES = 10

const emptyProduct: Omit<Product, "id"> = {
  name: "",
  slug: "",
  category: "İç Cephe Boyaları",
  categorySlug: "ic-cephe",
  description: "",
  features: [],
  coverage: "",
  dryingTime: "",
  price: "",
  colors: [],
  images: [],
}

export function ProductsManager({ products, categories, onAdd, onUpdate, onDelete }: ProductsManagerProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [formData, setFormData] = useState<Omit<Product, "id">>(emptyProduct)
  const [featuresInput, setFeaturesInput] = useState("")
  const [colorsInput, setColorsInput] = useState("")
  const [newImageUrl, setNewImageUrl] = useState("")
  const [isUploading, setIsUploading] = useState(false)
  const fileInputRef = React.useRef<HTMLInputElement>(null)

  const resetForm = () => {
    setFormData(emptyProduct)
    setFeaturesInput("")
    setColorsInput("")
    setNewImageUrl("")
    setEditingProduct(null)
  }

  const handleOpenCreate = () => {
    resetForm()
    setIsDialogOpen(true)
  }

  const handleOpenEdit = (product: Product) => {
    setEditingProduct(product)
    // Eski image alanını images'a dönüştür
    const existingImages = product.images || (product.image ? [product.image] : [])
    setFormData({
      name: product.name,
      slug: product.slug,
      category: product.category,
      categorySlug: product.categorySlug,
      description: product.description,
      features: product.features,
      coverage: product.coverage,
      dryingTime: product.dryingTime,
      price: product.price,
      colors: product.colors || [],
      images: existingImages,
    })
    setFeaturesInput(product.features.join(", "))
    setColorsInput((product.colors || []).join(", "))
    setNewImageUrl("")
    setIsDialogOpen(true)
  }

  const handleCategoryChange = (categorySlug: string) => {
    const category = categories.find(c => c.slug === categorySlug)
    if (category && category.slug !== "tumu") {
      setFormData(prev => ({
        ...prev,
        category: category.name,
        categorySlug: category.slug,
      }))
    }
  }

  const generateSlug = (name: string) => {
    return name
      .toLowerCase()
      .replace(/ü/g, "u")
      .replace(/ö/g, "o")
      .replace(/ı/g, "i")
      .replace(/ş/g, "s")
      .replace(/ğ/g, "g")
      .replace(/ç/g, "c")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "")
  }

  const handleAddImage = () => {
    if (!newImageUrl.trim()) return
    if ((formData.images || []).length >= MAX_IMAGES) {
      alert(`En fazla ${MAX_IMAGES} görsel ekleyebilirsiniz.`)
      return
    }
    setFormData(prev => ({
      ...prev,
      images: [...(prev.images || []), newImageUrl.trim()],
    }))
    setNewImageUrl("")
  }

  const handleRemoveImage = (index: number) => {
    setFormData(prev => ({
      ...prev,
      images: (prev.images || []).filter((_, i) => i !== index),
    }))
  }

  const handleMoveImage = (index: number, direction: "up" | "down") => {
    const images = [...(formData.images || [])]
    const newIndex = direction === "up" ? index - 1 : index + 1
    if (newIndex < 0 || newIndex >= images.length) return
    [images[index], images[newIndex]] = [images[newIndex], images[index]]
    setFormData(prev => ({ ...prev, images }))
  }

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || files.length === 0) return

    const currentCount = (formData.images || []).length
    const remainingSlots = MAX_IMAGES - currentCount
    
    if (remainingSlots <= 0) {
      alert(`En fazla ${MAX_IMAGES} görsel ekleyebilirsiniz.`)
      return
    }

    const filesToUpload = Array.from(files).slice(0, remainingSlots)
    setIsUploading(true)

    try {
      const uploadedUrls: string[] = []
      
      for (const file of filesToUpload) {
        // Dosya boyutu kontrolü (5MB)
        if (file.size > 5 * 1024 * 1024) {
          alert(`${file.name} dosyası 5MB'dan büyük, atlanıyor.`)
          continue
        }

        // Sadece resim dosyaları
        if (!file.type.startsWith('image/')) {
          alert(`${file.name} bir resim dosyası değil, atlanıyor.`)
          continue
        }

        const formDataUpload = new FormData()
        formDataUpload.append('file', file)

        const response = await fetch('/api/upload', {
          method: 'POST',
          body: formDataUpload,
        })

        if (response.ok) {
          const data = await response.json()
          uploadedUrls.push(data.url)
        } else {
          const error = await response.json()
          console.error('Upload failed:', error)
          alert(`${file.name} yüklenemedi: ${error.error}`)
        }
      }

      if (uploadedUrls.length > 0) {
        setFormData(prev => ({
          ...prev,
          images: [...(prev.images || []), ...uploadedUrls],
        }))
      }
    } catch (error) {
      console.error('Upload error:', error)
      alert('Yükleme sırasında bir hata oluştu.')
    } finally {
      setIsUploading(false)
      // Input'u temizle
      if (fileInputRef.current) {
        fileInputRef.current.value = ''
      }
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    const features = featuresInput.split(",").map(f => f.trim()).filter(Boolean)
    const colors = colorsInput.split(",").map(c => c.trim()).filter(Boolean)
    
    const productData: Product = {
      id: editingProduct?.id || Date.now().toString(),
      ...formData,
      slug: formData.slug || generateSlug(formData.name),
      features,
      colors,
      image: formData.images?.[0] || "", // Geriye uyumluluk için ilk görseli image'a da ata
    }

    if (editingProduct) {
      onUpdate(editingProduct.id, productData)
    } else {
      onAdd(productData)
    }

    setIsDialogOpen(false)
    resetForm()
  }

  const handleDelete = (id: string) => {
    if (confirm("Bu ürünü silmek istediğinize emin misiniz?")) {
      onDelete(id)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Ürün Yönetimi</h1>
          <p className="text-muted-foreground">Ürünlerinizi ekleyin, düzenleyin veya silin</p>
        </div>
        <Button onClick={handleOpenCreate}>
          <Plus className="w-4 h-4 mr-2" />
          Yeni Ürün Ekle
        </Button>
      </div>

      <div className="grid gap-4">
        {products.map((product) => (
          <Card key={product.id}>
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-4">
                {/* Ürün görseli */}
                {(product.images?.[0] || product.image) && (
                  <div className="w-16 h-16 rounded-md overflow-hidden bg-muted flex-shrink-0">
                    <img 
                      src={product.images?.[0] || product.image} 
                      alt={product.name}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).parentElement!.style.display = "none"
                      }}
                    />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-foreground truncate">{product.name}</h3>
                  <p className="text-sm text-muted-foreground">{product.category}</p>
                  <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{product.description}</p>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {product.colors && product.colors.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        {product.colors.slice(0, 3).map((color, i) => (
                          <span key={i} className="text-xs bg-muted px-2 py-1 rounded">{color}</span>
                        ))}
                        {product.colors.length > 3 && (
                          <span className="text-xs bg-muted px-2 py-1 rounded">+{product.colors.length - 3}</span>
                        )}
                      </div>
                    )}
                    {(product.images?.length || 0) > 0 && (
                      <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">
                        {product.images?.length} görsel
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="icon" onClick={() => handleOpenEdit(product)}>
                    <Pencil className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="icon" onClick={() => handleDelete(product.id)}>
                    <Trash2 className="w-4 h-4 text-destructive" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingProduct ? "Ürün Düzenle" : "Yeni Ürün Ekle"}
            </DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Ürün Adı *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Ürün adını girin"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="slug">URL Slug</Label>
                <Input
                  id="slug"
                  value={formData.slug}
                  onChange={(e) => setFormData(prev => ({ ...prev, slug: e.target.value }))}
                  placeholder="Otomatik oluşturulur"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="category">Kategori *</Label>
                <Select value={formData.categorySlug} onValueChange={handleCategoryChange}>
                  <SelectTrigger>
                    <SelectValue placeholder="Kategori seçin" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.filter(c => c.slug !== "tumu").map((cat) => (
                      <SelectItem key={cat.slug} value={cat.slug}>
                        {cat.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="price">Fiyat</Label>
                <Input
                  id="price"
                  value={formData.price}
                  onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value }))}
                  placeholder="Örn: 250 TL veya Teklif alın"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Açıklama *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Ürün açıklaması"
                rows={3}
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="coverage">Verim</Label>
                <Input
                  id="coverage"
                  value={formData.coverage}
                  onChange={(e) => setFormData(prev => ({ ...prev, coverage: e.target.value }))}
                  placeholder="Örn: 10-12 m²/L"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="dryingTime">Kuruma Süresi</Label>
                <Input
                  id="dryingTime"
                  value={formData.dryingTime}
                  onChange={(e) => setFormData(prev => ({ ...prev, dryingTime: e.target.value }))}
                  placeholder="Örn: 2-4 saat"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="features">Özellikler (virgülle ayırın)</Label>
              <Input
                id="features"
                value={featuresInput}
                onChange={(e) => setFeaturesInput(e.target.value)}
                placeholder="Özellik 1, Özellik 2, Özellik 3"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="colors">Renkler (virgülle ayırın)</Label>
              <Input
                id="colors"
                value={colorsInput}
                onChange={(e) => setColorsInput(e.target.value)}
                placeholder="Beyaz, Krem, Gri"
              />
            </div>

            {/* Çoklu Görsel Yönetimi */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Görseller (Maks. {MAX_IMAGES})</Label>
                <span className="text-sm text-muted-foreground">
                  {(formData.images || []).length} / {MAX_IMAGES}
                </span>
              </div>
              
              {/* Görsel Yükleme */}
              <div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleFileUpload}
                  className="hidden"
                  id="image-upload"
                />
                <Button
                  type="button"
                  variant="outline"
                  className="w-full h-24 border-dashed"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploading || (formData.images || []).length >= MAX_IMAGES}
                >
                  {isUploading ? (
                    <div className="flex items-center gap-2">
                      <Loader2 className="w-5 h-5 animate-spin" />
                      <span>Yükleniyor...</span>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center gap-1">
                      <Upload className="w-6 h-6" />
                      <span className="text-sm font-medium">Görsel Yükle</span>
                      <span className="text-xs text-muted-foreground">PNG, JPG, WEBP (Maks. 5MB)</span>
                    </div>
                  )}
                </Button>
              </div>

              {/* Mevcut Görseller */}
              {(formData.images || []).length > 0 && (
                <div className="space-y-2">
                  {(formData.images || []).map((img, index) => (
                    <div 
                      key={index} 
                      className="flex items-center gap-3 p-2 rounded-lg border border-border bg-muted/30"
                    >
                      {/* Görsel önizleme */}
                      <div className="w-16 h-16 rounded-md overflow-hidden bg-muted flex-shrink-0">
                        <img 
                          src={img} 
                          alt={`Görsel ${index + 1}`}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 24 24' fill='none' stroke='%23999' strokeWidth='2'%3E%3Crect x='3' y='3' width='18' height='18' rx='2' ry='2'/%3E%3Ccircle cx='8.5' cy='8.5' r='1.5'/%3E%3Cpolyline points='21 15 16 10 5 21'/%3E%3C/svg%3E"
                          }}
                        />
                      </div>
                      
                      {/* Bilgi ve etiket */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium text-foreground">
                            Görsel {index + 1}
                          </span>
                          {index === 0 && (
                            <span className="bg-primary text-primary-foreground text-xs px-1.5 py-0.5 rounded">
                              Ana Görsel
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground truncate mt-0.5">
                          {img}
                        </p>
                      </div>
                      
                      {/* Aksiyon butonları - her zaman görünür */}
                      <div className="flex items-center gap-1 flex-shrink-0">
                        {/* Yukarı taşı */}
                        <Button 
                          type="button" 
                          size="icon" 
                          variant="ghost" 
                          className="h-9 w-9"
                          onClick={() => handleMoveImage(index, "up")}
                          disabled={index === 0}
                        >
                          <ChevronUp className="w-4 h-4" />
                        </Button>
                        
                        {/* Aşağı taşı */}
                        <Button 
                          type="button" 
                          size="icon" 
                          variant="ghost" 
                          className="h-9 w-9"
                          onClick={() => handleMoveImage(index, "down")}
                          disabled={index === (formData.images || []).length - 1}
                        >
                          <ChevronDown className="w-4 h-4" />
                        </Button>
                        
                        {/* Sil */}
                        <Button 
                          type="button" 
                          size="icon" 
                          variant="ghost" 
                          className="h-9 w-9 text-destructive hover:text-destructive hover:bg-destructive/10"
                          onClick={() => handleRemoveImage(index)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              
              <p className="text-xs text-muted-foreground">
                İlk görsel ana görsel olarak kullanılır. Görselleri sürükleyerek sıralayabilirsiniz.
              </p>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                İptal
              </Button>
              <Button type="submit">
                {editingProduct ? "Güncelle" : "Ekle"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
