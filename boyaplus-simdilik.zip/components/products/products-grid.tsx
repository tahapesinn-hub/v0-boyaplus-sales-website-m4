import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { Product } from "@/lib/site-data"

interface ProductsGridProps {
  products: Product[]
}

export function ProductsGrid({ products }: ProductsGridProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  )
}

function ProductCard({ product }: { product: Product }) {
  // Gorseli al (images varsa ilkini, yoksa image'i)
  const productImage = product.images?.[0] || product.image
  
  return (
    <div className="group bg-card rounded-xl border border-border overflow-hidden hover:shadow-lg transition-shadow">
      {/* Kategori Etiketi - Gorsel disinda, kartin en ustunde */}
      <div className="px-4 pt-3 pb-2">
        <span className="inline-block px-2.5 py-1 bg-muted text-xs font-medium rounded-full text-muted-foreground">
          {product.category}
        </span>
      </div>

      {/* Product Image - Temiz, uzerine hicbir element binmiyor */}
      <div className="aspect-square bg-gradient-to-br from-muted/50 to-muted/20 overflow-hidden mx-3 rounded-lg">
        {productImage ? (
          <img 
            src={productImage} 
            alt={product.name}
            className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-300"
            onError={(e) => {
              (e.target as HTMLImageElement).style.display = "none"
            }}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <div className="w-20 h-20 rounded-full bg-primary/20" />
          </div>
        )}
      </div>

      {/* Product Info */}
      <div className="p-4">
        <h3 className="font-semibold text-foreground mb-2 group-hover:text-primary transition-colors line-clamp-2">
          {product.name}
        </h3>
        
        {/* Ozellik etiketleri */}
        <div className="flex flex-wrap gap-1.5 mb-3">
          {product.features.slice(0, 2).map((feature, index) => (
            <span 
              key={index}
              className="inline-block px-2 py-0.5 bg-muted text-xs rounded text-muted-foreground"
            >
              {feature}
            </span>
          ))}
        </div>

        {/* Fiyat */}
        <p className="text-lg font-bold text-primary mb-3">
          {product.price}
        </p>

        {/* Detay Butonu */}
        <Button size="sm" variant="outline" asChild className="w-full group/btn">
          <Link href={`/urunler/${product.slug}`}>
            Detay
            <ArrowRight className="ml-1 h-4 w-4 group-hover/btn:translate-x-0.5 transition-transform" />
          </Link>
        </Button>
      </div>
    </div>
  )
}
