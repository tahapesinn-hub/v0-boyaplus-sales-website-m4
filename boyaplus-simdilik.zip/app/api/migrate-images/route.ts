import { put } from '@vercel/blob'
import { supabaseRest } from "@/lib/db"
import { NextResponse } from "next/server"

// Bu endpoint mevcut ürünlerin dış URL görsellerini Blob'a taşır
export async function POST() {
  try {
    // Mevcut ürünleri al
    const products = await supabaseRest({
      table: "products",
      method: "GET",
    })

    if (!products || !Array.isArray(products)) {
      return NextResponse.json({ error: "Ürünler bulunamadı" }, { status: 404 })
    }

    const results: { productId: string; productName: string; migratedImages: string[]; errors: string[] }[] = []

    for (const product of products) {
      const productResult = {
        productId: product.id,
        productName: product.name,
        migratedImages: [] as string[],
        errors: [] as string[],
      }

      const images = product.images || []
      const newImages: string[] = []

      for (let i = 0; i < images.length; i++) {
        const imageUrl = images[i]
        
        // Zaten Blob URL'si ise atla
        if (imageUrl.includes('blob.vercel-storage.com')) {
          newImages.push(imageUrl)
          continue
        }

        try {
          // Dış URL'den görseli indir
          const response = await fetch(imageUrl)
          if (!response.ok) {
            productResult.errors.push(`${imageUrl} indirilemedi: ${response.status}`)
            newImages.push(imageUrl) // Eski URL'yi koru
            continue
          }

          const blob = await response.blob()
          
          // Blob'a yükle
          const timestamp = Date.now()
          const randomStr = Math.random().toString(36).substring(2, 8)
          const extension = imageUrl.split('.').pop()?.split('?')[0] || 'jpg'
          const filename = `products/${product.slug || product.id}/${timestamp}-${randomStr}.${extension}`

          const uploadResult = await put(filename, blob, {
            access: 'public',
          })

          newImages.push(uploadResult.url)
          productResult.migratedImages.push(uploadResult.url)
        } catch (error) {
          productResult.errors.push(`${imageUrl} yüklenemedi: ${error}`)
          newImages.push(imageUrl) // Eski URL'yi koru
        }
      }

      // Eğer değişiklik varsa veritabanını güncelle
      if (productResult.migratedImages.length > 0) {
        await supabaseRest({
          table: "products",
          method: "PATCH",
          filters: { "id": `eq.${product.id}` },
          body: { images: newImages },
        })
      }

      results.push(productResult)
    }

    return NextResponse.json({ 
      success: true, 
      message: "Görsel migrasyonu tamamlandı",
      results 
    })
  } catch (error) {
    console.error('Migration error:', error)
    return NextResponse.json({ error: "Migrasyon başarısız" }, { status: 500 })
  }
}
