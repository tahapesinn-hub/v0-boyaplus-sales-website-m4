import { NextRequest, NextResponse } from "next/server"
import { supabaseRest } from "@/lib/db"

// n8n ve diger otomasyon sistemleri icin blog olusturma API'si
// Admin paneldeki blog-manager.tsx ile birebir ayni veri yapisi

interface BlogCreateRequest {
  title: string           // Zorunlu - Blog basligi
  slug?: string           // Opsiyonel - Bos gelirse otomatik olusturulur
  category?: string       // Opsiyonel - Varsayilan: "Genel"
  author?: string         // Opsiyonel - Varsayilan: "Boyaplus Uzman Ekibi"
  image?: string          // Opsiyonel - Gorsel URL
  excerpt?: string        // Opsiyonel - Ozet
  seoTitle?: string       // Opsiyonel - SEO basligi
  seoDescription?: string // Opsiyonel - Meta description
  content: string         // Zorunlu - Blog icerigi
  published?: boolean     // Opsiyonel - true: yayinla, false: taslak (varsayilan: false)
}

// Slug olusturma (Turkce karakter destekli)
function generateSlug(title: string): string {
  return title
    .toLowerCase()
    .replace(/ğ/g, "g")
    .replace(/ü/g, "u")
    .replace(/ş/g, "s")
    .replace(/ı/g, "i")
    .replace(/ö/g, "o")
    .replace(/ç/g, "c")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
}

// Okuma suresi hesaplama
function calculateReadTime(content: string): number {
  const words = content.trim().split(/\s+/).length
  return Math.max(1, Math.ceil(words / 200))
}

export async function POST(request: NextRequest) {
  try {
    // Token dogrulama
    const authHeader = request.headers.get("authorization")
    const token = authHeader?.replace("Bearer ", "")
    
    const API_TOKEN = process.env.BLOG_API_TOKEN
    
    if (!API_TOKEN || token !== API_TOKEN) {
      return NextResponse.json(
        { error: "Yetkisiz erisim. Gecerli bir API token gerekli." },
        { status: 401 }
      )
    }

    const body: BlogCreateRequest = await request.json()

    // Zorunlu alan kontrolu
    if (!body.title || !body.content) {
      return NextResponse.json(
        { error: "title ve content alanlari zorunludur." },
        { status: 400 }
      )
    }

    // Degerleri hazirla (admin panelle ayni mantik)
    const title = body.title.trim()
    const slug = body.slug?.trim() || generateSlug(title)
    const category = body.category?.trim() || "Genel"
    const author = body.author?.trim() || "Boyaplus Uzman Ekibi"
    const image_url = body.image?.trim() || null
    const excerpt = body.excerpt?.trim() || body.content.substring(0, 160).replace(/<[^>]*>/g, '').trim() + "..."
    const seo_title = body.seoTitle?.trim() || title
    const meta_description = body.seoDescription?.trim() || excerpt
    const content = body.content.trim()
    const is_published = body.published === true
    const read_time = calculateReadTime(content.replace(/<[^>]*>/g, ''))

    // Slug benzersizlik kontrolu
    const existingPosts = await supabaseRest({
      table: "blog_posts",
      select: "id",
      filters: { slug: `eq.${slug}` }
    })

    let finalSlug = slug
    if (existingPosts && existingPosts.length > 0) {
      // Slug varsa timestamp ekle
      finalSlug = `${slug}-${Date.now()}`
    }

    const now = new Date().toISOString()

    // Blog yazisin veritabanina kaydet (admin panelle ayni kolonlar)
    const result = await supabaseRest({
      table: "blog_posts",
      method: "POST",
      body: {
        title,
        slug: finalSlug,
        excerpt,
        content,
        category,
        author,
        read_time,
        image_url,
        seo_title,
        meta_description,
        is_published,
        created_at: now,
        updated_at: now
      }
    })

    // Olusturulan postu getir
    const newPost = Array.isArray(result) ? result[0] : result

    return NextResponse.json({
      success: true,
      message: is_published ? "Blog yazisi yayinlandi" : "Blog yazisi taslak olarak kaydedildi",
      post: {
        id: newPost?.id,
        title: title,
        slug: finalSlug,
        published: is_published,
        url: `/blog/${finalSlug}`,
        createdAt: now
      }
    }, { status: 201 })

  } catch (error) {
    console.error("Blog olusturma hatasi:", error)
    return NextResponse.json(
      { error: "Blog yazisi olusturulamadi", details: String(error) },
      { status: 500 }
    )
  }
}

// API dokumantasyonu
export async function GET() {
  return NextResponse.json({
    name: "Boyaplus Blog API",
    version: "1.0",
    description: "n8n ve otomasyon sistemleri icin blog olusturma API'si",
    endpoint: "POST /api/blog-create",
    authentication: "Bearer token (BLOG_API_TOKEN)",
    fields: {
      title: { type: "string", required: true, description: "Blog basligi" },
      slug: { type: "string", required: false, description: "URL slug (bos ise otomatik olusturulur)" },
      category: { type: "string", required: false, default: "Genel", description: "Kategori adi" },
      author: { type: "string", required: false, default: "Boyaplus Uzman Ekibi", description: "Yazar adi" },
      image: { type: "string", required: false, description: "Gorsel URL" },
      excerpt: { type: "string", required: false, description: "Ozet (bos ise icerikten alinir)" },
      seoTitle: { type: "string", required: false, description: "SEO basligi (bos ise title kullanilir)" },
      seoDescription: { type: "string", required: false, description: "Meta description (bos ise excerpt kullanilir)" },
      content: { type: "string", required: true, description: "Blog icerigi (HTML destekler)" },
      published: { type: "boolean", required: false, default: false, description: "true: yayinla, false: taslak" }
    }
  })
}
