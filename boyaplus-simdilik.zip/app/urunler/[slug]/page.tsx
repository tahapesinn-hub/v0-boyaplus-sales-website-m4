"use client"

import { useState, useRef } from "react"
import { notFound, useParams } from "next/navigation"
import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { WhatsAppButton } from "@/components/whatsapp-button"
import { Button } from "@/components/ui/button"
import { useSiteDataReadOnly } from "@/hooks/use-site-data"
import { ArrowLeft, Check, Clock, Layers, MessageCircle, Phone, ChevronLeft, ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"

export default function ProductPage() {
  const params = useParams<{ slug: string }>()
  const { data, isLoading } = useSiteDataReadOnly()
  const [activeImageIndex, setActiveImageIndex] = useState(0)
  
  // Touch/Swipe state
  const touchStartX = useRef<number | null>(null)
  const touchEndX = useRef<number | null>(null)
  const minSwipeDistance = 50

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  const product = data.products.find(p => p.slug === params.slug)

  if (!product) {
    notFound()
  }

  // Görselleri al (images varsa onu, yoksa image'ı array olarak)
  const images = product.images?.length ? product.images : (product.image ? [product.image] : [])
  const hasImages = images.length > 0

  const whatsappMessage = `Merhaba, ${product.name} ürünü hakkında bilgi almak istiyorum.`

  const handlePrevImage = () => {
    setActiveImageIndex(prev => (prev === 0 ? images.length - 1 : prev - 1))
  }

  const handleNextImage = () => {
    setActiveImageIndex(prev => (prev === images.length - 1 ? 0 : prev + 1))
  }

  // Touch handlers for swipe
  const handleTouchStart = (e: React.TouchEvent) => {
    touchEndX.current = null
    touchStartX.current = e.targetTouches[0].clientX
  }

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndX.current = e.targetTouches[0].clientX
  }

  const handleTouchEnd = () => {
    if (!touchStartX.current || !touchEndX.current) return
    
    const distance = touchStartX.current - touchEndX.current
    const isLeftSwipe = distance > minSwipeDistance
    const isRightSwipe = distance < -minSwipeDistance

    if (isLeftSwipe && images.length > 1) {
      handleNextImage()
    }
    if (isRightSwipe && images.length > 1) {
      handlePrevImage()
    }

    touchStartX.current = null
    touchEndX.current = null
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        {/* Breadcrumb */}
        <div className="bg-muted/30 border-b border-border">
          <div className="container mx-auto px-4 md:px-6 py-4">
            <nav className="flex items-center gap-2 text-sm">
              <Link href="/" className="text-muted-foreground hover:text-foreground transition-colors">
                Ana Sayfa
              </Link>
              <span className="text-muted-foreground">/</span>
              <Link href="/urunler" className="text-muted-foreground hover:text-foreground transition-colors">
                Ürünler
              </Link>
              <span className="text-muted-foreground">/</span>
              <span className="text-foreground font-medium">{product.name}</span>
            </nav>
          </div>
        </div>

        {/* Product Detail */}
        <section className="py-12 md:py-16 bg-background">
          <div className="container mx-auto px-4 md:px-6">
            <Link 
              href="/urunler" 
              className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground transition-colors mb-8"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Tüm Ürünler
            </Link>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
              {/* Product Image Gallery - Mobilde temiz ve tam gorunum */}
              <div className="space-y-3">
                {/* Ana Görsel - Swipe destekli */}
                <div 
                  className="aspect-square bg-gradient-to-br from-muted/50 to-muted/20 rounded-xl lg:rounded-2xl relative overflow-hidden touch-pan-y"
                  onTouchStart={handleTouchStart}
                  onTouchMove={handleTouchMove}
                  onTouchEnd={handleTouchEnd}
                >
                  {hasImages ? (
                    <img 
                      src={images[activeImageIndex]} 
                      alt={`${product.name} - Görsel ${activeImageIndex + 1}`}
                      className="w-full h-full object-contain select-none pointer-events-none"
                      draggable={false}
                      onError={(e) => {
                        (e.target as HTMLImageElement).style.display = "none"
                      }}
                    />
                  ) : (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-32 h-32 lg:w-48 lg:h-48 rounded-full bg-primary/20" />
                    </div>
                  )}
                  
                  {/* Swipe navigation arrows - Desktop */}
                  {images.length > 1 && (
                    <>
                      <button
                        onClick={handlePrevImage}
                        className="absolute left-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-background/80 backdrop-blur-sm border border-border flex items-center justify-center text-foreground hover:bg-background transition-colors hidden lg:flex"
                        aria-label="Önceki görsel"
                      >
                        <ChevronLeft className="w-5 h-5" />
                      </button>
                      <button
                        onClick={handleNextImage}
                        className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-background/80 backdrop-blur-sm border border-border flex items-center justify-center text-foreground hover:bg-background transition-colors hidden lg:flex"
                        aria-label="Sonraki görsel"
                      >
                        <ChevronRight className="w-5 h-5" />
                      </button>
                    </>
                  )}
                  
                  {/* Swipe indicator dots - Mobile */}
                  {images.length > 1 && (
                    <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5 lg:hidden">
                      {images.map((_, index) => (
                        <button
                          key={index}
                          onClick={() => setActiveImageIndex(index)}
                          className={cn(
                            "w-2 h-2 rounded-full transition-all",
                            activeImageIndex === index 
                              ? "bg-primary w-4" 
                              : "bg-foreground/30"
                          )}
                          aria-label={`Görsel ${index + 1}`}
                        />
                      ))}
                    </div>
                  )}
                </div>

                {/* Thumbnail Görseller - Görsel altında */}
                {images.length > 1 && (
                  <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
                    {images.map((img, index) => (
                      <button
                        key={index}
                        onClick={() => setActiveImageIndex(index)}
                        className={cn(
                          "w-16 h-16 lg:w-20 lg:h-20 flex-shrink-0 rounded-lg overflow-hidden border-2 transition-all",
                          activeImageIndex === index 
                            ? "border-primary ring-2 ring-primary/20" 
                            : "border-border hover:border-muted-foreground"
                        )}
                      >
                        <img 
                          src={img} 
                          alt={`${product.name} - Küçük görsel ${index + 1}`}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            (e.target as HTMLImageElement).style.display = "none"
                          }}
                        />
                      </button>
                    ))}
                  </div>
                )}

                {/* Gorsel sayaci - Thumbnail altinda */}
                {images.length > 1 && (
                  <p className="text-center text-sm text-muted-foreground">
                    {activeImageIndex + 1} / {images.length}
                  </p>
                )}
              </div>

              {/* Product Info - Mobilde above the fold: isim, fiyat, buton */}
              <div className="space-y-6">
                {/* Mobilde ilk gorunen: Urun adi, fiyat, siparis butonu */}
                <div className="space-y-4">
                  {/* Kategori etiketi - Mobilde basligin ustunde kucuk */}
                  <span className="inline-block px-3 py-1 bg-muted text-xs font-medium rounded-full text-muted-foreground">
                    {product.category}
                  </span>
                  
                  <h1 className="text-2xl lg:text-4xl font-bold text-foreground">
                    {product.name}
                  </h1>
                  
                  {/* Fiyat - Mobilde hemen basligin altinda */}
                  <p className="text-2xl lg:text-3xl font-bold text-primary">{product.price}</p>
                  
                  {/* CTA Butonlari - Mobilde hemen fiyatin altinda (above the fold) */}
                  <div className="flex gap-3">
                    <Button size="lg" asChild className="flex-1 h-12 lg:h-14 bg-[#25D366] hover:bg-[#128C7E] text-white text-base">
                      <a 
                        href={`https://wa.me/${data.contact.whatsapp}?text=${encodeURIComponent(whatsappMessage)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <MessageCircle className="mr-2 h-5 w-5" />
                        Sipariş Ver
                      </a>
                    </Button>
                    <Button size="lg" variant="outline" asChild className="h-12 lg:h-14 px-4 bg-transparent">
                      <a href={`tel:${data.contact.phone.replace(/\s/g, '')}`}>
                        <Phone className="h-5 w-5" />
                      </a>
                    </Button>
                  </div>
                </div>

                {/* Urun aciklamasi */}
                <p className="text-muted-foreground leading-relaxed">
                  {product.description}
                </p>

                {/* Specs - Kompakt */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 lg:p-4 rounded-xl bg-muted/50 border border-border">
                    <div className="flex items-center gap-2 text-muted-foreground mb-1">
                      <Layers className="w-4 h-4" />
                      <span className="text-xs lg:text-sm">Kaplama</span>
                    </div>
                    <p className="text-sm lg:text-base font-semibold text-foreground">{product.coverage}</p>
                  </div>
                  <div className="p-3 lg:p-4 rounded-xl bg-muted/50 border border-border">
                    <div className="flex items-center gap-2 text-muted-foreground mb-1">
                      <Clock className="w-4 h-4" />
                      <span className="text-xs lg:text-sm">Kuruma</span>
                    </div>
                    <p className="text-sm lg:text-base font-semibold text-foreground">{product.dryingTime}</p>
                  </div>
                </div>

                {/* Colors */}
                {product.colors && product.colors.length > 0 && (
                  <div className="space-y-3">
                    <h2 className="text-base lg:text-lg font-semibold text-foreground">Mevcut Renkler</h2>
                    <div className="flex flex-wrap gap-2">
                      {product.colors.map((color, index) => (
                        <span key={index} className="px-3 py-1.5 bg-muted rounded-full text-sm text-foreground">
                          {color}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Features */}
                <div className="space-y-3">
                  <h2 className="text-base lg:text-lg font-semibold text-foreground">Özellikler</h2>
                  <ul className="grid grid-cols-1 gap-2">
                    {product.features.map((feature, index) => (
                      <li key={index} className="flex items-center gap-3">
                        <div className="w-5 h-5 rounded-full bg-accent/20 flex items-center justify-center shrink-0">
                          <Check className="w-3 h-3 text-accent" />
                        </div>
                        <span className="text-sm lg:text-base text-foreground">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Related Products CTA */}
        <section className="py-12 md:py-16 bg-muted/30 border-t border-border">
          <div className="container mx-auto px-4 md:px-6 text-center">
            <h2 className="text-2xl font-bold text-foreground mb-4">
              Diğer Ürünlerimizi Keşfedin
            </h2>
            <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
              Premium kalite boya çözümlerimizin tamamını inceleyerek projeniz için en uygun ürünü bulun.
            </p>
            <Button asChild>
              <Link href="/urunler">Tüm Ürünlere Göz At</Link>
            </Button>
          </div>
        </section>
      </main>
      <Footer contact={data.contact} categories={data.categories} />
      <WhatsAppButton whatsapp={data.contact.whatsapp} message={whatsappMessage} />
    </div>
  )
}
