"use client"

import { useState, useRef, useEffect } from "react"
import { notFound, useParams } from "next/navigation"
import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { WhatsAppButton } from "@/components/whatsapp-button"
import { Button } from "@/components/ui/button"
import { useSiteDataReadOnly } from "@/hooks/use-site-data"
import { ArrowLeft, Check, Clock, Layers, MessageCircle, Phone, ChevronLeft, ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"

export default function ProductPage() {
  const params = useParams<{ slug: string }>()
  const { data, isLoading } = useSiteDataReadOnly()
  const [activeImageIndex, setActiveImageIndex] = useState(0)
  
  // Touch/Swipe state
  const touchStartX = useRef<number | null>(null)
  const touchEndX = useRef<number | null>(null)
  const minSwipeDistance = 50

  // Product ve images'i hesapla (hook'lardan once kullanmak icin)
  const product = !isLoading ? data.products.find(p => p.slug === params.slug) : null
  const images = product?.images?.length ? product.images : (product?.image ? [product.image] : [])
  const hasImages = images.length > 0

  // Tüm görselleri preload et - Hook'lar her zaman cagrilmali
  useEffect(() => {
    if (images.length > 0) {
      images.forEach((src) => {
        const img = new window.Image()
        img.src = src
      })
    }
  }, [images])

  // Loading state
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  // Product not found
  if (!product) {
    notFound()
  }

  const whatsappMessage = `Merhaba, ${product.name} ürünü hakkında bilgi almak istiyorum.`

  const handlePrevImage = () => {
    setActiveImageIndex(prev => (prev === 0 ? images.length - 1 : prev - 1))
  }

  const handleNextImage = () => {
    setActiveImageIndex(prev => (prev === images.length - 1 ? 0 : prev + 1))
  }

  // Touch handlers for swipe
  const handleTouchStart = (e: React.TouchEvent) => {
    touchEndX.current = null
    touchStartX.current = e.targetTouches[0].clientX
  }

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndX.current = e.targetTouches[0].clientX
  }

  const handleTouchEnd = () => {
    if (!touchStartX.current || !touchEndX.current) return
    
    const distance = touchStartX.current - touchEndX.current
    const isLeftSwipe = distance > minSwipeDistance
    const isRightSwipe = distance < -minSwipeDistance

    if (isLeftSwipe && images.length > 1) {
      handleNextImage()
    }
    if (isRightSwipe && images.length > 1) {
      handlePrevImage()
    }

    touchStartX.current = null
    touchEndX.current = null
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        {/* Breadcrumb */}
        <div className="bg-muted/30 border-b border-border">
          <div className="container mx-auto px-4 md:px-6 py-4">
            <nav className="flex items-center gap-2 text-sm">
              <Link href="/" className="text-muted-foreground hover:text-foreground transition-colors">
                Ana Sayfa
              </Link>
              <span className="text-muted-foreground">/</span>
              <Link href="/urunler" className="text-muted-foreground hover:text-foreground transition-colors">
                Ürünler
              </Link>
              <span className="text-muted-foreground">/</span>
              <span className="text-foreground font-medium">{product.name}</span>
            </nav>
          </div>
        </div>

        {/* Product Detail */}
        <section className="py-6 md:py-12 lg:py-16 bg-background">
          <div className="container mx-auto px-4 md:px-6">
            <Link 
              href="/urunler" 
              className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground transition-colors mb-4 md:mb-8"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Tüm Ürünler
            </Link>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 lg:gap-12">
              {/* Product Image Gallery - Sadece ana gorsel, thumbnail yok */}
              <div className="relative z-0 space-y-3">
                {/* Ana Görsel - Swipe destekli */}
                <div 
                  className="aspect-square bg-gradient-to-br from-muted/50 to-muted/20 rounded-xl lg:rounded-2xl relative overflow-hidden touch-pan-y"
                  onTouchStart={handleTouchStart}
                  onTouchMove={handleTouchMove}
                  onTouchEnd={handleTouchEnd}
                >
                  {hasImages ? (
                    <>
                      {/* Tum gorselleri preload icin renderla ama sadece aktif olani goster */}
                      {images.map((src, index) => (
                        <img 
                          key={index}
                          src={src} 
                          alt={`${product.name} - Görsel ${index + 1}`}
                          className={cn(
                            "absolute inset-0 w-full h-full object-contain select-none pointer-events-none transition-opacity duration-200",
                            activeImageIndex === index ? "opacity-100" : "opacity-0"
                          )}
                          draggable={false}
                          loading={index === 0 ? "eager" : "lazy"}
                          onError={(e) => {
                            (e.target as HTMLImageElement).style.display = "none"
                          }}
                        />
                      ))}
                    </>
                  ) : (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-32 h-32 lg:w-48 lg:h-48 rounded-full bg-primary/20" />
                    </div>
                  )}
                  
                  {/* Swipe navigation arrows - Desktop */}
                  {images.length > 1 && (
                    <>
                      <button
                        onClick={handlePrevImage}
                        className="absolute left-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-background/80 backdrop-blur-sm border border-border flex items-center justify-center text-foreground hover:bg-background transition-colors hidden lg:flex"
                        aria-label="Önceki görsel"
                      >
                        <ChevronLeft className="w-5 h-5" />
                      </button>
                      <button
                        onClick={handleNextImage}
                        className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-background/80 backdrop-blur-sm border border-border flex items-center justify-center text-foreground hover:bg-background transition-colors hidden lg:flex"
                        aria-label="Sonraki görsel"
                      >
                        <ChevronRight className="w-5 h-5" />
                      </button>
                    </>
                  )}
                </div>
                
                {/* Indicator dots - Görselin dışında, altında */}
                {images.length > 1 && (
                  <div className="flex justify-center gap-2">
                    {images.map((_, index) => (
                      <button
                        key={index}
                        onClick={() => setActiveImageIndex(index)}
                        className={cn(
                          "w-2.5 h-2.5 rounded-full transition-all",
                          activeImageIndex === index 
                            ? "bg-primary w-6" 
                            : "bg-muted-foreground/30 hover:bg-muted-foreground/50"
                        )}
                        aria-label={`Görsel ${index + 1}`}
                      />
                    ))}
                  </div>
                )}
              </div>

              {/* Product Info - Mobilde above the fold: isim, fiyat, buton */}
              <div className="space-y-5 lg:space-y-6">
                {/* Mobilde ilk gorunen: Urun adi, fiyat, siparis butonu */}
                <div className="space-y-3">
                  {/* Kategori etiketi - Mobilde basligin ustunde kucuk */}
                  <span className="inline-block px-3 py-1 bg-muted text-xs font-medium rounded-full text-muted-foreground">
                    {product.category}
                  </span>
                  
                  <h1 className="text-2xl lg:text-4xl font-bold text-foreground leading-tight">
                    {product.name}
                  </h1>
                  
                  {/* Fiyat - Buyuk ve belirgin */}
                  <p className="text-3xl lg:text-4xl font-bold text-primary">{product.price}</p>
                </div>
                
                {/* CTA Butonlari - Ayri bir bolum, daha belirgin */}
                <div className="flex gap-3 p-4 -mx-4 md:mx-0 md:p-0 bg-muted/30 md:bg-transparent border-y border-border md:border-0">
                  <Button size="lg" asChild className="flex-1 h-14 bg-[#25D366] hover:bg-[#128C7E] text-white text-base font-semibold shadow-lg">
                    <a 
                      href={`https://wa.me/${data.contact.whatsapp}?text=${encodeURIComponent(whatsappMessage)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <MessageCircle className="mr-2 h-5 w-5" />
                      Hemen Sipariş Ver
                    </a>
                  </Button>
                  <Button size="lg" variant="outline" asChild className="h-14 px-5 bg-background">
                    <a href={`tel:${data.contact.phone.replace(/\s/g, '')}`}>
                      <Phone className="h-5 w-5" />
                    </a>
                  </Button>
                </div>

                {/* Specs - Kompakt, urun aciklamasindan once */}
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-3 rounded-lg bg-muted/50 border border-border">
                    <div className="flex items-center gap-2 text-muted-foreground mb-0.5">
                      <Layers className="w-4 h-4" />
                      <span className="text-xs">Kaplama</span>
                    </div>
                    <p className="text-sm font-semibold text-foreground">{product.coverage}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50 border border-border">
                    <div className="flex items-center gap-2 text-muted-foreground mb-0.5">
                      <Clock className="w-4 h-4" />
                      <span className="text-xs">Kuruma</span>
                    </div>
                    <p className="text-sm font-semibold text-foreground">{product.dryingTime}</p>
                  </div>
                </div>

                {/* Urun aciklamasi */}
                <p className="text-sm lg:text-base text-muted-foreground leading-relaxed">
                  {product.description}
                </p>

                {/* Colors */}
                {product.colors && product.colors.length > 0 && (
                  <div className="space-y-2">
                    <h2 className="text-sm lg:text-base font-semibold text-foreground">Mevcut Renkler</h2>
                    <div className="flex flex-wrap gap-1.5">
                      {product.colors.map((color, index) => (
                        <span key={index} className="px-2.5 py-1 bg-muted rounded-full text-xs text-foreground">
                          {color}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Features */}
                <div className="space-y-2">
                  <h2 className="text-sm lg:text-base font-semibold text-foreground">Özellikler</h2>
                  <ul className="grid grid-cols-1 gap-1.5">
                    {product.features.map((feature, index) => (
                      <li key={index} className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded-full bg-accent/20 flex items-center justify-center shrink-0">
                          <Check className="w-2.5 h-2.5 text-accent" />
                        </div>
                        <span className="text-sm text-foreground">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Related Products CTA */}
        <section className="py-8 md:py-12 bg-muted/30 border-t border-border">
          <div className="container mx-auto px-4 md:px-6 text-center">
            <h2 className="text-xl lg:text-2xl font-bold text-foreground mb-3">
              Diğer Ürünlerimizi Keşfedin
            </h2>
            <p className="text-sm lg:text-base text-muted-foreground mb-4 max-w-xl mx-auto">
              Premium kalite boya çözümlerimizin tamamını inceleyerek projeniz için en uygun ürünü bulun.
            </p>
            <Button asChild size="lg">
              <Link href="/urunler">Tüm Ürünlere Göz At</Link>
            </Button>
          </div>
        </section>
      </main>
      <Footer contact={data.contact} categories={data.categories} />
      <WhatsAppButton whatsapp={data.contact.whatsapp} message={whatsappMessage} />
    </div>
  )
}
